import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class KetNoiDB {
    private static final String DB_URL = "jdbc:sqlite:qlsv.db";

    public static Connection getConnection() {
        Connection conn = null;
        try {
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection(DB_URL);
            khoiTaoBang(conn);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    private static void khoiTaoBang(Connection conn) throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS SinhVien ("
                + "maSV TEXT PRIMARY KEY,"
                + "hoTen TEXT NOT NULL,"
                + "lop TEXT,"
                + "diem REAL"
                + ");";
        try (Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        }
    }
}