import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class FormChinh extends JFrame {
    public FormChinh() {
        setTitle("Form 2 - Man Hinh Chinh");
        setSize(420, 220);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel lblTitle = new JLabel("HE THONG QUAN LY SINH VIEN", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 16));
        panel.add(lblTitle, BorderLayout.NORTH);

        JPanel btnPanel = new JPanel(new GridLayout(1, 2, 15, 15));
        JButton btnQLSV = new JButton("Quan ly Sinh vien");
        JButton btnLogout = new JButton("Dang xuat");
        btnPanel.add(btnQLSV);
        btnPanel.add(btnLogout);
        panel.add(btnPanel, BorderLayout.CENTER);

        btnQLSV.addActionListener(e -> {
            new FormQuanLySV().setVisible(true);
            this.dispose();
        });

        btnLogout.addActionListener(e -> {
            new FormDangNhap().setVisible(true);
            this.dispose();
        });

        add(panel);
    }
}