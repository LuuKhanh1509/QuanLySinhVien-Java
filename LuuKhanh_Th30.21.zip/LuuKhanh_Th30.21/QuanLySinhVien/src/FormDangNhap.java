import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class FormDangNhap extends JFrame {
    private JTextField txtUser;
    private JPasswordField txtPass;

    public FormDangNhap() {
        setTitle("Form 1 - Dang Nhap He Thong");
        setSize(360, 190);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        panel.add(new JLabel("Tai khoan:"));
        txtUser = new JTextField();
        panel.add(txtUser);

        panel.add(new JLabel("Mat khau:"));
        txtPass = new JPasswordField();
        panel.add(txtPass);

        JButton btnLogin = new JButton("Dang nhap");
        JButton btnExit = new JButton("Thoat");
        panel.add(btnLogin);
        panel.add(btnExit);

        btnLogin.addActionListener(e -> xuLyDangNhap());
        btnExit.addActionListener(e -> System.exit(0));

        add(panel);
    }

    private void xuLyDangNhap() {
        String user = txtUser.getText().trim();
        String pass = new String(txtPass.getPassword()).trim();

        if (user.equals("admin") && pass.equals("123456")) {
            new FormChinh().setVisible(true);
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Sai tai khoan hoac mat khau!", "Loi", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FormDangNhap().setVisible(true));
    }
}