import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class FormQuanLySV extends JFrame {
    private JTextField txtMaSV, txtHoTen, txtLop, txtDiem, txtTimKiem;
    private JTable table;
    private DefaultTableModel model;

    public FormQuanLySV() {
        setTitle("Form 3 - Quan Ly Danh Sach Sinh Vien");
        setSize(720, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JPanel pnlInput = new JPanel(new GridLayout(4, 2, 8, 8));
        pnlInput.setBorder(BorderFactory.createTitledBorder("Thong tin sinh vien"));

        pnlInput.add(new JLabel("Ma SV:"));
        txtMaSV = new JTextField();
        pnlInput.add(txtMaSV);

        pnlInput.add(new JLabel("Ho Ten:"));
        txtHoTen = new JTextField();
        pnlInput.add(txtHoTen);

        pnlInput.add(new JLabel("Lop:"));
        txtLop = new JTextField();
        pnlInput.add(txtLop);

        pnlInput.add(new JLabel("Diem TB:"));
        txtDiem = new JTextField();
        pnlInput.add(txtDiem);

        JPanel pnlButtons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        JButton btnThem = new JButton("Them");
        JButton btnSua = new JButton("Sua");
        JButton btnXoa = new JButton("Xoa");
        JButton btnLamMoi = new JButton("Lam moi");
        JButton btnQuayLai = new JButton("Quay lai");
        pnlButtons.add(btnThem);
        pnlButtons.add(btnSua);
        pnlButtons.add(btnXoa);
        pnlButtons.add(btnLamMoi);
        pnlButtons.add(btnQuayLai);

        JPanel pnlSearch = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        pnlSearch.add(new JLabel("Tim kiem (Ma/Ten):"));
        txtTimKiem = new JTextField(20);
        JButton btnTim = new JButton("Tim");
        pnlSearch.add(txtTimKiem);
        pnlSearch.add(btnTim);

        JPanel pnlTop = new JPanel(new BorderLayout());
        pnlTop.add(pnlInput, BorderLayout.NORTH);
        pnlTop.add(pnlButtons, BorderLayout.CENTER);
        pnlTop.add(pnlSearch, BorderLayout.SOUTH);

        add(pnlTop, BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"Ma SV", "Ho Ten", "Lop", "Diem TB"}, 0);
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        loadData("");

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                if (row >= 0) {
                    txtMaSV.setText(model.getValueAt(row, 0).toString());
                    txtHoTen.setText(model.getValueAt(row, 1).toString());
                    txtLop.setText(model.getValueAt(row, 2).toString());
                    txtDiem.setText(model.getValueAt(row, 3).toString());
                    txtMaSV.setEditable(false);
                }
            }
        });

        btnThem.addActionListener(e -> themSV());
        btnSua.addActionListener(e -> suaSV());
        btnXoa.addActionListener(e -> xoaSV());
        btnTim.addActionListener(e -> loadData(txtTimKiem.getText().trim()));
        btnLamMoi.addActionListener(e -> lamMoiForm());
        btnQuayLai.addActionListener(e -> {
            new FormChinh().setVisible(true);
            this.dispose();
        });
    }

    private void loadData(String keyword) {
        model.setRowCount(0);
        String sql = "SELECT * FROM SinhVien WHERE maSV LIKE ? OR hoTen LIKE ?";
        try (Connection conn = KetNoiDB.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, "%" + keyword + "%");
            pstmt.setString(2, "%" + keyword + "%");
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("maSV"),
                    rs.getString("hoTen"),
                    rs.getString("lop"),
                    rs.getDouble("diem")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void themSV() {
        String ma = txtMaSV.getText().trim();
        String ten = txtHoTen.getText().trim();
        String lop = txtLop.getText().trim();
        String diemStr = txtDiem.getText().trim();

        if (ma.isEmpty() || ten.isEmpty() || diemStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui long nhap du Ma SV, Ho Ten va Diem!");
            return;
        }

        try {
            double diem = Double.parseDouble(diemStr);
            String sql = "INSERT INTO SinhVien(maSV, hoTen, lop, diem) VALUES(?, ?, ?, ?)";
            try (Connection conn = KetNoiDB.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, ma);
                pstmt.setString(2, ten);
                pstmt.setString(3, lop);
                pstmt.setDouble(4, diem);
                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Them thanh cong!");
                lamMoiForm();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Diem phai la so!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Ma SV da ton tai hoac loi CSDL!");
        }
    }

    private void suaSV() {
        String ma = txtMaSV.getText().trim();
        if (ma.isEmpty() || txtMaSV.isEditable()) {
            JOptionPane.showMessageDialog(this, "Vui long chon sinh vien trong bang de sua!");
            return;
        }

        try {
            double diem = Double.parseDouble(txtDiem.getText().trim());
            String sql = "UPDATE SinhVien SET hoTen = ?, lop = ?, diem = ? WHERE maSV = ?";
            try (Connection conn = KetNoiDB.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, txtHoTen.getText().trim());
                pstmt.setString(2, txtLop.getText().trim());
                pstmt.setDouble(3, diem);
                pstmt.setString(4, ma);
                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Cap nhat thanh cong!");
                lamMoiForm();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Diem phai la so!");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void xoaSV() {
        String ma = txtMaSV.getText().trim();
        if (ma.isEmpty() || txtMaSV.isEditable()) {
            JOptionPane.showMessageDialog(this, "Vui long chon sinh vien trong bang de xoa!");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Ban chac chan muon xoa sinh vien " + ma + "?", "Xac nhan", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            String sql = "DELETE FROM SinhVien WHERE maSV = ?";
            try (Connection conn = KetNoiDB.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, ma);
                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Xoa thanh cong!");
                lamMoiForm();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    private void lamMoiForm() {
        txtMaSV.setText("");
        txtHoTen.setText("");
        txtLop.setText("");
        txtDiem.setText("");
        txtTimKiem.setText("");
        txtMaSV.setEditable(true);
        loadData("");
    }
}